# WILD CLASH Online — Multiplayer Server Starter

این بسته، بک‌اند اولیه‌ی آنلاین بازی است: ساخت اتاق خصوصی، کد اتاق، پیوستن با کد، Quick Match و انتقال وضعیت بازیکن‌ها از طریق WebSocket.

> **مهم:** این بک‌اند را باید جدا از Netlify منتشر کنی. وجود این سرور به‌تنهایی بازی HTML را به بازی آنلاین کامل تبدیل نمی‌کند؛ فرانت‌اند بازی باید به پیام‌های WebSocket وصل شود و حرکت، مبارزه، جان و حذف بازیکن‌ها را با سرور هماهنگ کند. فایل `client/multiplayer-client.js` یک کلاینت عمومی برای اتصال و لابی است، اما هنوز به منطق داخلی بازی اصلی وصل نشده است.

## فایل‌ها

- `server.js` — سرور WebSocket با اتاق‌ها و Quick Match
- `package.json` — وابستگی و دستور اجرا
- `render.yaml` — تنظیم اولیه‌ی Render
- `client/multiplayer-client.js` — کلاینت نمونه برای اتصال از HTML
- `public/index.html` — صفحه‌ی تست اتصال/اتاق، مستقل از بازی اصلی

## اجرای محلی روی کامپیوتر

نیازمند Node.js نسخه 20 یا جدیدتر:

```bash
npm install
npm start
```

سپس باز کن: `http://localhost:3000/health`

برای تست WebSocket، فایل `public/index.html` را با یک وب‌سرور محلی باز کن؛ در صورت اجرای سرور روی همان دستگاه، آدرس `ws://localhost:3000` را وارد کن. برای تست دو دستگاه، هر دو باید بتوانند به آدرس سرور دسترسی شبکه‌ای داشته باشند.

## انتشار رایگان با Render

1. وارد GitHub شو و یک repository جدید بساز؛ مثلاً `wild-clash-multiplayer`.
2. محتویات همین ZIP را از حالت فشرده خارج کن و فایل‌ها را در ریشه‌ی repository بارگذاری کن. پوشه‌ها را هم حفظ کن.
3. در Render گزینه‌ی **New + → Web Service** را بزن و repository را متصل کن.
4. تنظیمات:
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Health Check Path: `/health`
5. Deploy را بزن و منتظر بمان تا وضعیت سرویس Live شود.
6. آدرس HTTPS شبیه `https://your-service.onrender.com` را کپی کن. آدرس WebSocket برای بازی می‌شود همان آدرس با `wss://`، مثلاً `wss://your-service.onrender.com`.
7. آدرس نمونه/ساختگی را در بازی نگذار؛ فقط آدرسی را وارد کن که Render واقعاً ساخته است.

**نکته‌ی پلن رایگان:** ممکن است سرویس پس از مدتی بی‌استفاده‌ماندن بخوابد و اولین اتصال دوباره چند لحظه طول بکشد. شرایط پلن‌ها ممکن است تغییر کند.

## پیام‌های پروتکل

کلاینت بعد از اتصال می‌تواند این پیام‌ها را بفرستد:

- `{ "type": "hello", "name": "Player" }`
- `{ "type": "create_room", "name": "Player" }`
- `{ "type": "join_room", "code": "ABC234", "name": "Player" }`
- `{ "type": "quick_match", "name": "Player" }`
- `{ "type": "ready", "ready": true }`
- `{ "type": "start_match" }`
- `{ "type": "player_state", "state": { "x": 0, "y": 0, "z": 0, "yaw": 0, "hp": 100, "alive": true, "action": "move" } }`
- `{ "type": "leave_room" }`

سرور پیام‌های `joined`, `room_update`, `player_joined`, `player_left`, `state_update`, `match_started` و `error` را برمی‌گرداند.

## امنیت و محدودیت‌ها

این نسخه برای نمونه‌سازی و آزمایش است. رویدادهای مبارزه هنوز authoritative نیستند؛ کلاینت می‌تواند مختصات/جان خودش را پیشنهاد بدهد. قبل از انتشار عمومی باید اعتبارسنجی سروری واقعی برای سرعت حرکت، برخورد، حمله، cooldown، دمیج و نتیجه‌ی مسابقه پیاده‌سازی شود. همچنین Quick Match فعلاً بازیکن را وارد اولین اتاق عمومیِ قابل‌استفاده می‌کند؛ این matchmaking رتبه‌بندی‌شده یا ضدتقلب نیست.
