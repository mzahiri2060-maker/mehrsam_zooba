const http = require("node:http");
const crypto = require("node:crypto");
const { WebSocketServer, WebSocket } = require("ws");

const PORT = Number(process.env.PORT || 3000);
const HOST = "0.0.0.0";
const MAX_PLAYERS_PER_ROOM = 8;
const MAX_ROOMS = 500;
const MAX_MESSAGE_BYTES = 16 * 1024;
const rooms = new Map();
const clients = new Map();
const quickQueue = [];

function makeId() {
  return crypto.randomBytes(8).toString("hex");
}
function makeCode() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 6; i++) code += alphabet[crypto.randomInt(alphabet.length)];
  return code;
}
function send(ws, payload) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(payload));
}
function broadcast(room, payload, exceptId = null) {
  for (const [id, player] of room.players) {
    if (id !== exceptId) send(player.ws, payload);
  }
}
function roomSummary(room) {
  return {
    code: room.code,
    players: [...room.players.values()].map(p => ({
      id: p.id, name: p.name, ready: p.ready, state: p.state
    })),
    maxPlayers: MAX_PLAYERS_PER_ROOM,
    createdAt: room.createdAt
  };
}
function createRoom(isPrivate = true) {
  if (rooms.size >= MAX_ROOMS) return null;
  let code;
  do { code = makeCode(); } while (rooms.has(code));
  const room = { code, isPrivate, players: new Map(), createdAt: Date.now(), started: false };
  rooms.set(code, room);
  return room;
}
function cleanName(value) {
  const s = String(value || "Player").replace(/[<>\\u0000-\\u001f]/g, "").trim();
  return (s || "Player").slice(0, 18);
}
function removeFromQueue(id) {
  for (let i = quickQueue.length - 1; i >= 0; i--) {
    if (quickQueue[i] === id) quickQueue.splice(i, 1);
  }
}
function joinRoom(ws, room, name) {
  const client = clients.get(ws);
  if (!client || client.roomCode) return false;
  if (room.players.size >= MAX_PLAYERS_PER_ROOM) {
    send(ws, { type: "error", code: "ROOM_FULL", message: "This room is full." });
    return false;
  }
  const player = {
    id: client.id,
    name: cleanName(name || client.name),
    ws,
    ready: false,
    state: { x: 0, y: 0, z: 0, yaw: 0, hp: 100, alive: true, action: "idle" },
    lastUpdate: 0
  };
  room.players.set(player.id, player);
  client.roomCode = room.code;
  client.name = player.name;
  removeFromQueue(client.id);
  send(ws, { type: "joined", selfId: player.id, room: roomSummary(room), private: room.isPrivate });
  broadcast(room, { type: "player_joined", player: { id: player.id, name: player.name, ready: false, state: player.state } }, player.id);
  broadcast(room, { type: "room_update", room: roomSummary(room) });
  return true;
}
function leaveRoom(ws, notify = true) {
  const client = clients.get(ws);
  if (!client || !client.roomCode) return;
  const room = rooms.get(client.roomCode);
  const id = client.id;
  client.roomCode = null;
  if (!room) return;
  room.players.delete(id);
  if (notify) broadcast(room, { type: "player_left", playerId: id });
  if (room.players.size === 0) {
    rooms.delete(room.code);
  } else {
    if (room.started && room.players.size < 2) room.started = false;
    broadcast(room, { type: "room_update", room: roomSummary(room) });
  }
}
function findQuickRoom() {
  for (const room of rooms.values()) {
    if (!room.isPrivate && !room.started && room.players.size < MAX_PLAYERS_PER_ROOM) return room;
  }
  return createRoom(false);
}
function handleMessage(ws, raw) {
  const client = clients.get(ws);
  if (!client) return;
  let msg;
  try { msg = JSON.parse(raw.toString()); }
  catch { return send(ws, { type: "error", code: "BAD_JSON", message: "Invalid JSON message." }); }
  if (!msg || typeof msg.type !== "string") return;
  switch (msg.type) {
    case "hello": {
      client.name = cleanName(msg.name);
      send(ws, { type: "welcome", playerId: client.id, serverTime: Date.now(), protocol: 1 });
      break;
    }
    case "create_room": {
      if (client.roomCode) leaveRoom(ws);
      const room = createRoom(true);
      if (!room) return send(ws, { type: "error", code: "SERVER_BUSY", message: "Too many active rooms. Try again soon." });
      joinRoom(ws, room, cleanName(msg.name || client.name));
      break;
    }
    case "join_room": {
      const code = String(msg.code || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6);
      const room = rooms.get(code);
      if (!room) return send(ws, { type: "error", code: "ROOM_NOT_FOUND", message: "Room code not found." });
      if (client.roomCode) leaveRoom(ws);
      joinRoom(ws, room, cleanName(msg.name || client.name));
      break;
    }
    case "quick_match": {
      if (client.roomCode) leaveRoom(ws);
      removeFromQueue(client.id);
      let room = findQuickRoom();
      if (!room) return send(ws, { type: "error", code: "SERVER_BUSY", message: "Matchmaking is busy. Try again." });
      joinRoom(ws, room, cleanName(msg.name || client.name));
      send(ws, { type: "matchmaking", status: "matched", roomCode: room.code });
      break;
    }
    case "leave_room": {
      leaveRoom(ws);
      send(ws, { type: "left_room" });
      break;
    }
    case "ready": {
      const room = rooms.get(client.roomCode);
      const player = room && room.players.get(client.id);
      if (!player) break;
      player.ready = Boolean(msg.ready);
      broadcast(room, { type: "player_ready", playerId: client.id, ready: player.ready });
      broadcast(room, { type: "room_update", room: roomSummary(room) });
      break;
    }
    case "start_match": {
      const room = rooms.get(client.roomCode);
      if (!room || room.players.size < 2) {
        return send(ws, { type: "error", code: "NEED_PLAYERS", message: "At least two players are required." });
      }
      if (room.started) break;
      room.started = true;
      const seed = crypto.randomInt(1, 2147483647);
      broadcast(room, { type: "match_started", roomCode: room.code, seed, players: roomSummary(room).players });
      break;
    }
    case "player_state": {
      const room = rooms.get(client.roomCode);
      const player = room && room.players.get(client.id);
      if (!player || !msg.state || typeof msg.state !== "object") break;
      const now = Date.now();
      if (now - player.lastUpdate < 33) break;
      player.lastUpdate = now;
      const s = msg.state;
      const number = (v, fallback, min, max) => {
        const n = Number(v);
        return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : fallback;
      };
      player.state = {
        x: number(s.x, player.state.x, -10000, 10000),
        y: number(s.y, player.state.y, -1000, 1000),
        z: number(s.z, player.state.z, -10000, 10000),
        yaw: number(s.yaw, player.state.yaw, -100000, 100000),
        hp: number(s.hp, player.state.hp, 0, 100),
        alive: s.alive !== false && Number(s.hp) !== 0,
        action: ["idle", "move", "attack", "hit", "dead"].includes(s.action) ? s.action : "idle"
      };
      broadcast(room, { type: "state_update", playerId: client.id, state: player.state }, client.id);
      break;
    }
    case "game_event": {
      const room = rooms.get(client.roomCode);
      if (!room || !room.started) break;
      const allowed = new Set(["attack", "hit", "eliminated", "emote", "game_over"]);
      if (!allowed.has(msg.event)) break;
      // Event payload is intentionally small and never trusted as authoritative damage.
      broadcast(room, { type: "game_event", playerId: client.id, event: msg.event,
        targetId: typeof msg.targetId === "string" ? msg.targetId.slice(0, 64) : null,
        data: msg.data && typeof msg.data === "object" ? { emote: String(msg.data.emote || "").slice(0, 24) } : {}
      }, client.id);
      break;
    }
    case "ping":
      send(ws, { type: "pong", at: Date.now(), echo: msg.at || null });
      break;
    default:
      send(ws, { type: "error", code: "UNKNOWN_MESSAGE", message: "Unknown message type." });
  }
}

const fs = require("node:fs");
const path = require("node:path");
const PUBLIC_DIR = path.join(__dirname, "public");
const CLIENT_FILE = path.join(__dirname, "client", "multiplayer-client.js");

const server = http.createServer((req, res) => {
  const pathname = new URL(req.url, "http://localhost").pathname;
  if (pathname === "/health") {
    res.writeHead(200, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" });
    res.end(JSON.stringify({ ok: true, service: "wild-clash-multiplayer", rooms: rooms.size, clients: clients.size, time: Date.now() }));
    return;
  }
  if (pathname === "/" || pathname === "/index.html") {
    res.writeHead(200, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
    fs.createReadStream(path.join(PUBLIC_DIR, "index.html")).pipe(res);
    return;
  }
  if (pathname === "/client/multiplayer-client.js") {
    res.writeHead(200, { "content-type": "text/javascript; charset=utf-8", "cache-control": "no-store" });
    fs.createReadStream(CLIENT_FILE).pipe(res);
    return;
  }
  res.writeHead(404, { "content-type": "application/json; charset=utf-8" });
  res.end(JSON.stringify({ error: "Not found" }));
});
const wss = new WebSocketServer({ server, maxPayload: MAX_MESSAGE_BYTES });

wss.on("connection", (ws) => {
  const client = { id: makeId(), name: "Player", roomCode: null, isAlive: true };
  clients.set(ws, client);
  ws.isAlive = true;
  ws.on("pong", () => { ws.isAlive = true; });
  send(ws, { type: "connected", playerId: client.id, serverTime: Date.now() });
  ws.on("message", raw => handleMessage(ws, raw));
  ws.on("close", () => {
    removeFromQueue(client.id);
    leaveRoom(ws);
    clients.delete(ws);
  });
  ws.on("error", () => {});
});

const heartbeat = setInterval(() => {
  for (const ws of wss.clients) {
    if (ws.isAlive === false) { ws.terminate(); continue; }
    ws.isAlive = false;
    if (ws.readyState === WebSocket.OPEN) ws.ping();
  }
}, 30000);
heartbeat.unref();

server.listen(PORT, HOST, () => {
  console.log(`WILD CLASH multiplayer server listening on ${HOST}:${PORT}`);
});
process.on("SIGTERM", () => {
  clearInterval(heartbeat);
  for (const ws of wss.clients) ws.close(1001, "Server shutting down");
  server.close(() => process.exit(0));
});