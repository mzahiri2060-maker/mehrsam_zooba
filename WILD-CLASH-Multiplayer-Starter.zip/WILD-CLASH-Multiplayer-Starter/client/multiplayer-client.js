/*
 * WILD CLASH WebSocket client helper.
 * Include this file in your HTML, then:
 *   const wc = new WildClashMultiplayer({ url: "wss://YOUR-REAL-SERVER.onrender.com" });
 *   wc.connect("Player");
 *   wc.onMessage((message) => console.log(message));
 *   wc.createRoom("Player");
 *   wc.joinRoom("ABC234", "Player");
 *   wc.quickMatch("Player");
 *
 * This helper is not yet wired to the original game's movement/combat internals.
 */
(function (global) {
  "use strict";
  class WildClashMultiplayer {
    constructor(options = {}) {
      this.url = options.url || "";
      this.socket = null;
      this.handlers = new Set();
      this.lastError = null;
    }
    onMessage(fn) {
      if (typeof fn !== "function") return () => {};
      this.handlers.add(fn);
      return () => this.handlers.delete(fn);
    }
    emit(message) {
      if (!this.socket || this.socket.readyState !== WebSocket.OPEN) {
        throw new Error("Not connected to the multiplayer server.");
      }
      this.socket.send(JSON.stringify(message));
    }
    connect(name = "Player") {
      if (!this.url) throw new Error("Set the real WebSocket server URL first.");
      if (this.socket && [WebSocket.OPEN, WebSocket.CONNECTING].includes(this.socket.readyState)) return Promise.resolve();
      return new Promise((resolve, reject) => {
        let settled = false;
        const ws = new WebSocket(this.url);
        this.socket = ws;
        ws.addEventListener("open", () => {
          this.emit({ type: "hello", name });
          if (!settled) { settled = true; resolve(); }
        }, { once: true });
        ws.addEventListener("message", event => {
          let data;
          try { data = JSON.parse(event.data); } catch { return; }
          if (data.type === "error") this.lastError = data;
          for (const fn of this.handlers) {
            try { fn(data); } catch (e) { console.error("WILD CLASH message handler error", e); }
          }
        });
        ws.addEventListener("error", () => {
          const error = new Error("Could not connect to the multiplayer server.");
          if (!settled) { settled = true; reject(error); }
        });
        ws.addEventListener("close", () => {
          for (const fn of this.handlers) {
            try { fn({ type: "disconnected" }); } catch {}
          }
        });
      });
    }
    createRoom(name = "Player") { this.emit({ type: "create_room", name }); }
    joinRoom(code, name = "Player") { this.emit({ type: "join_room", code, name }); }
    quickMatch(name = "Player") { this.emit({ type: "quick_match", name }); }
    setReady(ready) { this.emit({ type: "ready", ready: Boolean(ready) }); }
    startMatch() { this.emit({ type: "start_match" }); }
    sendPlayerState(state) { this.emit({ type: "player_state", state }); }
    sendGameEvent(event, targetId = null, data = {}) { this.emit({ type: "game_event", event, targetId, data }); }
    leaveRoom() { this.emit({ type: "leave_room" }); }
    disconnect() {
      if (this.socket) this.socket.close(1000, "Client disconnected");
      this.socket = null;
    }
  }
  global.WildClashMultiplayer = WildClashMultiplayer;
})(window);